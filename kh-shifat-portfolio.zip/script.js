/* =====================================================
   EDIT YOUR DETAILS HERE (only place you need to change)
   ===================================================== */
const siteConfig = {
    name: "KH Shifat",
    title: "Web Designer & Developer",
    location: "Singapore",
    whatsapp: "8801743796216",   // digits with country code, no + or spaces. e.g. 6591234567
    email: "YOUR_EMAIL",
    website: "hasankhshifat.com",            // e.g. khshifat.com
    instagram: "YOUR_INSTAGRAM",        // full URL, e.g. https://instagram.com/yourname
    facebook: "YOUR_FACEBOOK",
    linkedin: "YOUR_LINKEDIN",
    inquiryEmail: "hasankhshifat@gmail.com", // inquiries are emailed here (FormSubmit)
    projectsCount: "100+ Projects"      // shown in the hero proof box
};

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const isSet = v => v && !v.startsWith("YOUR_");
document.documentElement.classList.add("js");

/* ---- Apply config ---- */
$$("[data-cfg]").forEach(el => {
    const k = el.dataset.cfg;
    el.textContent = k === "nameUpper" ? siteConfig.name.toUpperCase() : siteConfig[k];
});
const proofNum = $("#proofNum");
if (proofNum) proofNum.textContent = siteConfig.projectsCount;

const whatsappNumber = siteConfig.whatsapp;
const waMessage = "Hello KH Shifat, I would like to discuss a website project.";
const waLink = (msg = waMessage) => `https://wa.me/${whatsappNumber.replace(/\D/g, "")}?text=${encodeURIComponent(msg)}`;

const socials = [
    ["Facebook", "FB", siteConfig.facebook],
    ["Instagram", "IG", siteConfig.instagram],
    ["LinkedIn", "IN", siteConfig.linkedin],
    ["WhatsApp", "WA", isSet(whatsappNumber) ? waLink() : ""]
];
["heroSoc", "footSoc"].forEach(id => {
    const el = $("#" + id);
    if (el) el.innerHTML = socials.map(([n, s, u]) =>
        `<a href="${isSet(u) || u.startsWith("http") ? u : "#"}" aria-label="${n}" title="${n}" >${s}</a>`).join("");
});

/* ---- JSON-LD ---- */
try {
    const ld = $("#ld"), d = JSON.parse(ld.textContent), url = isSet(siteConfig.website) ? `https://${siteConfig.website}/` : "";
    const [p, s] = d["@graph"];
    p.name = siteConfig.name; p.jobTitle = siteConfig.title;
    if (url) { p.url = s.url = url; }
    p.sameAs = [siteConfig.facebook, siteConfig.instagram, siteConfig.linkedin].filter(isSet);
    ld.textContent = JSON.stringify(d);
} catch (e) {}

/* ---- WhatsApp button ---- */
const waBtn = $("#waBtn");
if (waBtn) waBtn.addEventListener("click", e => {
    e.preventDefault();
    if (!isSet(whatsappNumber)) { alert("Add your WhatsApp number in script.js (siteConfig.whatsapp)."); return; }
    location.href = waLink();
});

/* ---- Marquee: duplicate content for a seamless loop ---- */
const track = $("#track");
if (track) track.innerHTML += track.innerHTML;

/* ---- Mobile menu ---- */
const burger = $("#burger"), nav = $("#nav");
const setMenu = open => {
    if (!nav || !burger) return;
    nav.classList.toggle("open", open);
    burger.setAttribute("aria-expanded", open);
    burger.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    document.body.style.overflow = open ? "hidden" : "";
};
if (burger && nav) {
    burger.addEventListener("click", () => setMenu(!nav.classList.contains("open")));
    $$("#nav a").forEach(a => a.addEventListener("click", () => setMenu(false)));
    matchMedia("(min-width:901px)").addEventListener("change", e => e.matches && setMenu(false));
}
document.addEventListener("keydown", e => { if (e.key === "Escape") { setMenu(false); typeof closeViewer === "function" && closeViewer(); } });

/* ---- Active nav link ---- */
const links = $$("#nav a[href^='#']:not(.btn)");
const secs = ["home", "services", "projects", "about", "contact"].map(id => document.getElementById(id));
const navIO = new IntersectionObserver(es => es.forEach(en => {
    if (en.isIntersecting) links.forEach(l => l.classList.toggle("active", l.getAttribute("href") === "#" + en.target.id));
}), { rootMargin: "-45% 0px -50% 0px" });
secs.forEach(s => s && navIO.observe(s));

/* ---- Scroll reveal ---- */
const io = new IntersectionObserver(es => es.forEach(en => {
    if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
}), { threshold: .12 });
$$(".rv").forEach((el, i) => { el.style.transitionDelay = (i % 3) * 80 + "ms"; io.observe(el); });

/* ---- Progress bar + back to top ---- */
const bar = $("#progress"), toTop = $("#top");
if (bar && toTop) {
    const onScroll = () => {
        const h = document.documentElement, max = h.scrollHeight - h.clientHeight;
        bar.style.transform = `scaleX(${max > 0 ? h.scrollTop / max : 0})`;
        toTop.classList.toggle("show", h.scrollTop > 700);
    };
    addEventListener("scroll", onScroll, { passive: true }); onScroll();
    toTop.addEventListener("click", () => scrollTo({ top: 0 }));
}

/* ---- Custom cursor (mouse only) ---- */
const cursorEl = $("#cursor");
if (cursorEl && matchMedia("(hover:hover) and (pointer:fine)").matches && !matchMedia("(prefers-reduced-motion:reduce)").matches) {
    document.body.classList.add("cur-on");
    addEventListener("mousemove", e => { cursorEl.style.transform = `translate(${e.clientX}px,${e.clientY}px)`; }, { passive: true });
    document.addEventListener("mouseover", e => cursorEl.classList.toggle("big", !!e.target.closest("a,button,.card,.svc li")));
}


/* ---- WhatsApp country-code dropdown (default: Singapore; change defaultCountry) ---- */
const defaultCountry = "SG";
const countryList = "AF|Afghanistan|93;AL|Albania|355;DZ|Algeria|213;AD|Andorra|376;AO|Angola|244;AG|Antigua and Barbuda|1268;AR|Argentina|54;AM|Armenia|374;AU|Australia|61;AT|Austria|43;AZ|Azerbaijan|994;BS|Bahamas|1242;BH|Bahrain|973;BD|Bangladesh|880;BB|Barbados|1246;BY|Belarus|375;BE|Belgium|32;BZ|Belize|501;BJ|Benin|229;BT|Bhutan|975;BO|Bolivia|591;BA|Bosnia and Herzegovina|387;BW|Botswana|267;BR|Brazil|55;BN|Brunei|673;BG|Bulgaria|359;BF|Burkina Faso|226;BI|Burundi|257;KH|Cambodia|855;CM|Cameroon|237;CA|Canada|1;CV|Cape Verde|238;CF|Central African Republic|236;TD|Chad|235;CL|Chile|56;CN|China|86;CO|Colombia|57;KM|Comoros|269;CG|Congo|242;CD|Congo (DRC)|243;CR|Costa Rica|506;CI|Côte d'Ivoire|225;HR|Croatia|385;CU|Cuba|53;CY|Cyprus|357;CZ|Czechia|420;DK|Denmark|45;DJ|Djibouti|253;DM|Dominica|1767;DO|Dominican Republic|1809;EC|Ecuador|593;EG|Egypt|20;SV|El Salvador|503;GQ|Equatorial Guinea|240;ER|Eritrea|291;EE|Estonia|372;SZ|Eswatini|268;ET|Ethiopia|251;FJ|Fiji|679;FI|Finland|358;FR|France|33;GA|Gabon|241;GM|Gambia|220;GE|Georgia|995;DE|Germany|49;GH|Ghana|233;GR|Greece|30;GD|Grenada|1473;GT|Guatemala|502;GN|Guinea|224;GW|Guinea-Bissau|245;GY|Guyana|592;HT|Haiti|509;HN|Honduras|504;HK|Hong Kong|852;HU|Hungary|36;IS|Iceland|354;IN|India|91;ID|Indonesia|62;IR|Iran|98;IQ|Iraq|964;IE|Ireland|353;IL|Israel|972;IT|Italy|39;JM|Jamaica|1876;JP|Japan|81;JO|Jordan|962;KZ|Kazakhstan|7;KE|Kenya|254;KI|Kiribati|686;XK|Kosovo|383;KW|Kuwait|965;KG|Kyrgyzstan|996;LA|Laos|856;LV|Latvia|371;LB|Lebanon|961;LS|Lesotho|266;LR|Liberia|231;LY|Libya|218;LI|Liechtenstein|423;LT|Lithuania|370;LU|Luxembourg|352;MO|Macau|853;MG|Madagascar|261;MW|Malawi|265;MY|Malaysia|60;MV|Maldives|960;ML|Mali|223;MT|Malta|356;MH|Marshall Islands|692;MR|Mauritania|222;MU|Mauritius|230;MX|Mexico|52;FM|Micronesia|691;MD|Moldova|373;MC|Monaco|377;MN|Mongolia|976;ME|Montenegro|382;MA|Morocco|212;MZ|Mozambique|258;MM|Myanmar|95;NA|Namibia|264;NR|Nauru|674;NP|Nepal|977;NL|Netherlands|31;NZ|New Zealand|64;NI|Nicaragua|505;NE|Niger|227;NG|Nigeria|234;KP|North Korea|850;MK|North Macedonia|389;NO|Norway|47;OM|Oman|968;PK|Pakistan|92;PW|Palau|680;PS|Palestine|970;PA|Panama|507;PG|Papua New Guinea|675;PY|Paraguay|595;PE|Peru|51;PH|Philippines|63;PL|Poland|48;PT|Portugal|351;PR|Puerto Rico|1787;QA|Qatar|974;RO|Romania|40;RU|Russia|7;RW|Rwanda|250;KN|Saint Kitts and Nevis|1869;LC|Saint Lucia|1758;VC|Saint Vincent|1784;WS|Samoa|685;SM|San Marino|378;ST|São Tomé and Príncipe|239;SA|Saudi Arabia|966;SN|Senegal|221;RS|Serbia|381;SC|Seychelles|248;SL|Sierra Leone|232;SG|Singapore|65;SK|Slovakia|421;SI|Slovenia|386;SB|Solomon Islands|677;SO|Somalia|252;ZA|South Africa|27;KR|South Korea|82;SS|South Sudan|211;ES|Spain|34;LK|Sri Lanka|94;SD|Sudan|249;SR|Suriname|597;SE|Sweden|46;CH|Switzerland|41;SY|Syria|963;TW|Taiwan|886;TJ|Tajikistan|992;TZ|Tanzania|255;TH|Thailand|66;TL|Timor-Leste|670;TG|Togo|228;TO|Tonga|676;TT|Trinidad and Tobago|1868;TN|Tunisia|216;TR|Türkiye|90;TM|Turkmenistan|993;TV|Tuvalu|688;UG|Uganda|256;UA|Ukraine|380;AE|United Arab Emirates|971;GB|United Kingdom|44;US|United States|1;UY|Uruguay|598;UZ|Uzbekistan|998;VU|Vanuatu|678;VA|Vatican City|39;VE|Venezuela|58;VN|Vietnam|84;YE|Yemen|967;ZM|Zambia|260;ZW|Zimbabwe|263";
const flag = c => [...c].map(x => String.fromCodePoint(127397 + x.charCodeAt(0))).join("");
const ccSelect = $("#cc");
if (ccSelect) ccSelect.innerHTML = countryList.split(";").map(s => {
    const [iso, name, code] = s.split("|");
    return `<option value="${code}"${iso === defaultCountry ? " selected" : ""}>${/^[A-Z]{2}$/.test(iso) && iso !== "XK" ? flag(iso) + " " : ""}+${code} ${name}</option>`;
}).join("");

/* ---- Contact form ---- */
const form = $("#inquiry");
if (form) {
    const rules = {
        name: v => v.trim().length > 1 || "Enter your name.",
        email: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) || "Enter a valid email address.",
        whatsapp: v => (/^[\d\s()-]+$/.test(v) && v.replace(/\D/g, "").length >= 5 && v.replace(/\D/g, "").length <= 14) || "Enter your number without the country code, e.g. 9123 4567.",
        type: v => !!v || "Choose a project type.",
        budget: v => !!v || "Choose a budget range.",
        message: v => v.trim().length >= 10 || "Tell me a little about your project (10+ characters)."
    };
    const check = f => {
        const r = rules[f.name]; if (!r) return true;
        const res = r(f.value), ok = res === true;
        f.classList.toggle("bad", !ok);
        f.setAttribute("aria-invalid", !ok);
        f.closest(".field, label").querySelector(".err").textContent = ok ? "" : res;
        return ok;
    };
    $$("input,select,textarea", form).forEach(f => f.addEventListener("blur", () => check(f)));
    form.addEventListener("submit", async e => {
        e.preventDefault();
        const fields = $$("input,select,textarea", form);
        const bad = fields.filter(f => !check(f));
        if (bad.length) { bad[0].focus(); return; }
        const data = Object.fromEntries(new FormData(form));
        data.whatsapp = "+" + data.cc + " " + data.whatsapp.trim(); delete data.cc;

        const trap = data.hp_x7; delete data.hp_x7;         // spam trap: only bots fill this hidden field

        /* Inquiries are emailed to siteConfig.inquiryEmail through FormSubmit (free, no account).
           FIRST TIME ONLY: FormSubmit emails you an activation link, click it once and inquiries start arriving.
           To use another service (Formspree, EmailJS, your own API) replace the fetch below. */
        const waText = `${waMessage}\nName: ${data.name}\nBusiness: ${data.business || "-"}\nProject: ${data.type}\nBudget: ${data.budget}\nMessage: ${data.message}`;
        const btn = $("button[type=submit]", form), label = btn.firstChild.textContent;
        btn.disabled = true; btn.firstChild.textContent = "Sending... ";
        const ok = $("#ok"), okt = $("#okt"), okwa = $("#okwa");
        okt.textContent = "Sending your inquiry..."; ok.classList.remove("bad"); okwa.style.display = "none";
        ok.hidden = false; ok.scrollIntoView({ block: "nearest", behavior: "smooth" });
        let sent = false;
        const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 15000);
        try {
            if (trap) throw new Error("bot");
            const res = await fetch(`https://formsubmit.co/ajax/${siteConfig.inquiryEmail}`, {
                method: "POST", signal: ctl.signal,
                headers: { "Content-Type": "application/json", Accept: "application/json" },
                body: JSON.stringify({ ...data, _subject: `New project inquiry from ${data.name}`, _replyto: data.email, _template: "table", _captcha: "false" })
            });
            const r = await res.json();
            sent = res.ok && String(r.success) !== "false";
        } catch (err) { sent = false; console.warn("Inquiry email failed:", err); }
        clearTimeout(timer);
        btn.disabled = false; btn.firstChild.textContent = label;

        if (trap) sent = true;                              // bots get a fake success and nothing is sent
        ok.classList.toggle("bad", !sent);
        okt.textContent = sent
            ? "Thank you! Your inquiry has been sent. I'll reply within 24 hours. You can also message me on WhatsApp."
            : "Sorry, the inquiry could not be sent by email. Please send it on WhatsApp instead.";
        okwa.href = isSet(whatsappNumber) ? waLink(waText) : "#";
        okwa.style.display = isSet(whatsappNumber) ? "" : "none";
        if (sent) form.reset();
        ok.hidden = false; ok.scrollIntoView({ block: "nearest", behavior: "smooth" });
    });
}

/* ---- Live desktop preview in project thumbnails (1440px wide, scaled to fit) ---- */
const fit = () => $$(".thumb iframe").forEach(f => f.style.transform = `scale(${f.parentElement.clientWidth / 1440})`);
const ro = new ResizeObserver(fit);
$$(".thumb").forEach(t => ro.observe(t));

/* ---- Open project links inside this website (no new tabs) ---- */
const viewer = $("#viewer"), vf = $("#vframe");
if (viewer && vf) {
    let lastFocus;
    function closeViewer() {
        if (viewer.hidden) return;
        viewer.hidden = true; vf.removeAttribute("srcdoc"); vf.src = "about:blank";
        document.body.style.overflow = "";
        lastFocus && lastFocus.focus();
    }
    function openViewer(url, title) {
        lastFocus = document.activeElement;
        vf.removeAttribute("srcdoc"); $("#vopen").style.display = ""; vf.src = url; $("#vtitle").textContent = title; $("#vopen").href = url;
        viewer.hidden = false; document.body.style.overflow = "hidden";
        $("#vclose").focus();
    }
    $$(".card a").forEach(a => a.addEventListener("click", e => {
        e.preventDefault();
        const u = a.getAttribute("href");
        const card = a.closest(".card"), title = card.querySelector("h3").textContent;
        if (u.startsWith("http")) return openViewer(u, title);
        /* No link set yet: show the demo image with a note (add the real URL in index.html) */
        lastFocus = document.activeElement;
        vf.srcdoc = `<body style="margin:0;min-height:100vh;display:grid;place-items:center;font:600 16px system-ui;text-align:center;color:#555;background:#f5f5f3"><div style="padding:20px"><img src="${card.querySelector("img").src}" style="max-width:100%;border-radius:14px;border:1px solid #ddd"><p>Demo preview. Add this project's link in index.html to show the live site.</p></div>`;
        $("#vtitle").textContent = title; $("#vopen").style.display = "none";
        viewer.hidden = false; document.body.style.overflow = "hidden"; $("#vclose").focus();
    }));
    $("#vclose").addEventListener("click", closeViewer);
    viewer.addEventListener("click", e => { if (e.target === viewer) closeViewer(); });
}
